#!/bin/bash

sudo chown -R root:wheel sangfor.app.proxy.hook.kext 
sudo chmod -R 700 sangfor.app.proxy.hook.kext 
sudo chown -R root:wheel tun.kext 
sudo chmod -R 700 tun.kext 

