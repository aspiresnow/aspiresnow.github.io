#!/bin/bash

cd $1
cd ./kext
./do.sh
exitcode=0
modulename="sangfor.app.proxy.hook"
kextstat  | grep $modulename
if [ ! $? -eq 0 ]
then
	kextload -t sangfor.app.proxy.hook.kext
	exitcode=$?
fi
exit $exitcode