#!/bin/bash

cd `dirname $0`

#Mac OS 10.7、10.8 清空dns缓存
killall -HUP mDNSResponder

exit 1