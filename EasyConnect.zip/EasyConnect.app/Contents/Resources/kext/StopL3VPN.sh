#!/bin/bash

cd $1
cd ./kext

modulename="sangfor.ssl.tun"
kextstat  | grep $modulename
if [ $? -eq 0 ]
then
	kextunload  -b $modulename
fi