#!/bin/bash

cd $1
cd ./kext
./do.sh
exitcode=0
modulename="sangfor.ssl.tun"
kextstat  | grep $modulename
if [ ! $? -eq 0 ]
then 
	kextload  -t tun.kext
	exitcode=$?
fi
exit $exitcode