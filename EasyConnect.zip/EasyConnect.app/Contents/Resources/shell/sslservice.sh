#!/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/X11/bin:$PATH
export PATH

cd `dirname $0`
ECHOME=$(dirname $(pwd))
ECPATH=/Applications/EasyConnect.app/Contents/Resources/bin/CSClient.app/Contents/MacOS/CSClient

umask u=rwx,g=rwx,o=rwx

JAVALOCK=/tmp/SangforSSLJava.lock
if [ ! -f $JAVALOCK ]
then
	touch $JAVALOCK
	chmod 0777 $JAVALOCK
fi

#env check
RETSTR=`/bin/bash $ECHOME/shell/envcheck.sh none`
if [ $? -ne 0 ]; then
	echo "check env failed."
	exit 1
fi

if [ ! -f "$ECPATH" ]
then
    echo "$ECPATH not exist!"
    exit 1
fi

params="$@"
open -a /Applications/EasyConnect.app/Contents/Resources/bin/CSClient.app/Contents/MacOS/CSClient --args $params &
if [ $? -ne 0 ]
then
    exit 1
fi

#startup service
localbin=$ECHOME/bin/svpnservice
if [ ! -f $localbin ]
then
	echo "$localbin not exist!"
	exit 1
fi

if [ -u $localbin ] && [ -g $localbin ]
then
	cd $ECHOME/bin/
	let trytimes=10
	while [ $trytimes -gt 0 ]
	do
		$localbin -h $ECHOME/
		if [ $? -eq 0 ]
		then
			let trytimes=0
			exit 0;
		else
			let trytimes=$trytimes-1
			sleep 2
		fi
	done
else
	echo "$localbin not -u"
	exit 1
fi

exit 0

