#!/bin/bash

#
#envcheck.sh
#
#environment check for unix
#

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/X11/bin:$PATH
export PATH

KERNEL_MIN_LINUX=2.6.13
KERNEL_MIN_DARWIN=8.0.0

COM_APPLE_KPI_MACH_MIN=8.0.0
COM_APPLE_KPI_BSD_MIN=8.0.0
COM_APPLE_KPI_LIBKERN_MIN=8.0.0
COM_APPLE_KPI_UNSUPPORTED_MIN=8.0.0

#
#see how we were called.
#

KERNEL_NAME=`uname`

function compare_version()
{
	local version_1=`echo $1 | awk -F'.' '{printf "%05d%05d%05d", $1,$2,$3}'`
	local version_2=`echo $2 | awk -F'.' '{printf "%05d%05d%05d", $1,$2,$3}'`

	if   [ "$version_1" \< "$version_2" ]; then
		return 1;
	elif [ "$version_1" \> "$version_2" ]; then
		return 3;
	else
		return 2;
	fi
}

#check kernel version
case "$KERNEL_NAME" in
Linux)
	KERNEL_VERSION=`uname -r`
	compare_version $KERNEL_VERSION $KERNEL_MIN_LINUX
	if [ $? -lt 2 ]; then
		echo $"$KERNEL_NAME kernel version $KERNEL_VERSION is less than $KERNEL_MIN_LINUX."
		exit 1;
	fi
	;;
Darwin)
	KERNEL_VERSION=`uname -r`
	compare_version $KERNEL_VERSION $KERNEL_MIN_DARWIN
	if [ $? -lt 2 ]; then
		echo $"$KERNEL_NAME kernel version $KERNEL_VERSION is less than $KERNEL_MIN_DARWIN."
		exit 1;
	fi

	COM_APPLE_KPI_MACH=`kextstat | grep com.apple.kpi.mach | awk -F'[()]' '{printf $2}'`
	compare_version $COM_APPLE_KPI_MACH $COM_APPLE_KPI_MACH_MIN
	if [ $? -lt 2 ]; then
		echo $"com.apple.kpi.mach version $COM_APPLE_KPI_MACH is less than $COM_APPLE_KPI_MACH_MIN."
		exit 1;
	fi

	COM_APPLE_KPI_BSD=`kextstat | grep com.apple.kpi.bsd | awk -F'[()]' '{printf $2}'`
	compare_version $COM_APPLE_KPI_BSD $COM_APPLE_KPI_BSD_MIN
	if [ $? -lt 2 ]; then
		echo $"com.apple.kpi.bsd version $COM_APPLE_KPI_BSD is less than $COM_APPLE_KPI_BSD_MIN."
		exit 1;
	fi

	COM_APPLE_KPI_LIBKERN=`kextstat | grep com.apple.kpi.libkern | awk -F'[()]' '{printf $2}'`
	compare_version $COM_APPLE_KPI_LIBKERN $COM_APPLE_KPI_LIBKERN_MIN
	if [ $? -lt 2 ]; then
		echo $"com.apple.kpi.libkern version $COM_APPLE_KPI_LIBKERN is less than $COM_APPLE_KPI_LIBKERN_MIN."
		exit 1;
	fi

	COM_APPLE_KPI_UNSUPPORTED=`kextstat | grep com.apple.kpi.unsupported | awk -F'[()]' '{printf $2}'`
	compare_version $COM_APPLE_KPI_UNSUPPORTED $COM_APPLE_KPI_UNSUPPORTED_MIN
	if [ $? -lt 2 ]; then
		echo $"com.apple.kpi.unsupported version $COM_APPLE_KPI_UNSUPPORTED is less than $COM_APPLE_KPI_UNSUPPORTED_MIN."
		exit 1;
	fi
	;;
*)
	echo $"$KERNEL_NAME kernel version is unsupported."
	exit 1;
esac

function check_cmd()
{
	which $1 > /dev/null
	if [ $? -ne 0 ]; then
		echo $"no $1"
		exit 1;
	fi
}

function check_l3vpn()
{
	case "$KERNEL_NAME" in
	Linux)
		;;
	Darwin)
		;;
	*)
		echo $"$KERNEL_NAME kernel version is unsupported."
		exit 1;
	esac
}

function check_tcp()
{
	case "$KERNEL_NAME" in
	Linux)
		check_cmd iptables
		;;
	Darwin)
		;;
	*)
		echo $"$KERNEL_NAME kernel version is unsupported."
		exit 1;
	esac
}

function check_vline()
{
	case "$KERNEL_NAME" in
	Linux)
		check_cmd route
		;;
	Darwin)
		check_cmd route
		;;
	*)
		echo $"$KERNEL_NAME kernel version is unsupported."
		exit 1;
	esac
}

case "$1" in
l3vpn)
	check_l3vpn
	;;
tcp)
	check_tcp
	;;
vline)
	check_vline
	;;
none)
	;;
*)
	echo $"Usage: $0 {none|l3vpn|tcp|vline}"
	exit 1;
esac

exit 0;

