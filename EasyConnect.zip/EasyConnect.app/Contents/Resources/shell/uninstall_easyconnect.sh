#!/bin/sh
EASYMONITORPATH=/Library/LaunchDaemons/com.sangfor.EasyMonitor.plist
ECAGENTPROXYPATH=/Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
ECPATH=/Applications/EasyConnect.app
ECPLUGIN="/Library/Internet Plug-Ins/EasyConnectPlugin.plugin"

function stop_modules()
{
	launchctl unload /Library/LaunchDaemons/com.sangfor.EasyMonitor.plist

	username=`stat -f %Su /dev/console`
	sudo -u $username launchctl unload /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
	loginusers=`ps aux | grep -v grep | grep loginwindow | awk '{print $1}'`
	for loginuser in $loginusers
	do
		echo "deal ECAgentProxy of "$loginuser
		contextpid=$(ps -axj | grep loginwindow | awk "/^$loginuser / {print \$2;exit}")
		if [[ -z "$contextpid" ]]; then
			continue
		fi
		launchctl bsexec $contextpid sudo -u $loginuser launchctl unload /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
	done

	killall EasyMonitor
	killall ECAgent
	killall svpnservice
	killall CSClient
	killall EasyConnect
	killall ECAgentProxy
	proxypids=$(ps aux | grep -v grep | grep ECAgentProxy | awk '{print $2}')
	for proxypid in $proxypids
	do
    	kill -9 $proxypid
	done
}
function remove_modules()
{
	#remove old EC
	if [ -e $ECPATH ]
	then
	   rm -rf $ECPATH
	fi

	#remove old plugin
	if [ -e "$ECPLUGIN" ]
	then
	    rm -rf "$ECPLUGIN"
	fi

	if [ -L "$ECPLUGIN" ]
	then
	    rm -rf "$ECPLUGIN"
	fi

	#remove Damons and Agents
	if [ -e $EASYMONITORPATH ]
	then
		rm -rf $EASYMONITORPATH
	fi

	if [ -e $ECAGENTPROXYPATH ]
	then
		rm -rf $ECAGENTPROXYPATH
	fi

	#remove tmp file
	rm -rf /tmp/SangforSSL.lock
	rm -rf /tmp/SangforSSLJava.lock
	rm -rf /tmp/com.sangfor.ca.sha
	rm -rf /tmp/com.sangfor.lockcert
	rm -rf /tmp/com.sangfor.lockecagent
	rm -rf /tmp/sangfor.ec.rundata
}

function unloadtcpkext()
{
	modulename="sangfor.app.proxy.hook"
	kextstat  | grep $modulename
	if [ $? -ne 0 ]; then
		echo "do not find tcp kext load"
		return
	fi

	# 0 success 1 failed
	unloadok=1 
	unloadtimes=0
	while [ 1 ]
	do
		unloadtimes=`expr $unloadtimes + 1`
		kextunload -v 6 -b $modulename
		unloadok=$?
		dmesg > /tmp/EasyConnect.unloadtcpkextdmesg.log 2>&1
		if [ $unloadok -eq 0 ]; then
        	break
    	fi

		#内核扩展里最多支持了40次，这里写39次是为了避免强制卸载内核扩展出错
    	if [ $unloadtimes -ge 39 ]; then
			echo "unload kext failed"
        	break
    	else
			echo "unload kext failed, try again, code= "$unloadok" try times: "$unloadtimes 
			sleep 1
		fi
	done
	
	rm -rf /tmp/back.sangfor.older_tcp_kext_md5

	echo "tun kext load over"
}

#sangfor.ssl.tun 直接卸载
function unloadtunkext()
{
	modulename="sangfor.ssl.tun"
	kextstat  | grep $modulename
	if [ $? -ne 0 ]; then
		echo "do not find tun kext load"
		return
	fi

	kextunload -v 6 -b $modulename
	dmesg > /tmp/EasyConnect.unloadtunkextdmesg.log 2>&1
	rm -rf /tmp/back.sangfor.older_tcp_tun_md5

	echo "tun kext load over"
}

#0 succeed, other fail
function unloadkext()
{
	unloadtunkext
	unloadtcpkext
}

function checkstatus()
{
	modulename="sangfor.app.proxy.hook"
	kextstat  | grep $modulename
	if [ $? -eq 0 ]; then
		echo "still has kext extion, recommend restart mac!"
	else 
		echo "check over!"
	fi
}


echo "===========start uninstall easyconnect==========="

if [ "$EUID" -ne 0 ] ; then 
  echo "please run as root"
  exit 0
fi

echo "1. stop modules..."
stop_modules

echo "2. remove modules..."
remove_modules

echo "3. unload kext..."
unloadkext

echo "4. check status"
checkstatus

echo "===========over uninstall easyconnect============"
