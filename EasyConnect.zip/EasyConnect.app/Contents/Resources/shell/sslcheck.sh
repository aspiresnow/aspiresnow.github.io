#!/bin/bash

#VERSION 7.5.0.48927
#build-20140303 16:00

#file check
#@return succeed 0, fail 1

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:$PATH
export PATH

#TMPPATH=$(dirname $(pwd))
#echo $TMPPATH
cd `dirname $0`
ECHOME=$(dirname $(pwd))
#cd $TMPPATH
echo $ECHOME

#check dir
subdirs=("bin" "conf" "shell" "kext")
for subdir in ${subdirs[*]}
do
	if [ ! -d $ECHOME/$subdir ]
	then
		exit 1
	fi
done

#check svpnservice
binfiles=("svpnservice")
for binfile in ${binfiles[*]}
do
	if [ ! -f $ECHOME/${subdirs[0]}/$binfile ]
	then
		exit 1
	fi
done
#check SUID bit
if [ ! -u $ECHOME/${subdirs[0]}/${binfiles[0]} ]
then
	exit 1
fi
#check SGID bit
if [ ! -g $ECHOME/${subdirs[0]}/${binfiles[0]} ]
then
	exit 1
fi

#check conf file
etcfiles=("ConfModuleMap.xml" "Module.xml")
for etcfile in ${etcfiles[*]}
do
	if [ ! -f $ECHOME/${subdirs[1]}/$etcfile ]
	then
		exit 1
	fi
done

#check script file
shellfiles=("sslservice.sh" "envcheck.sh")
for shellfile in ${shellfiles[*]}
do
	if [ ! -f $ECHOME/${subdirs[2]}/$shellfile ]
	then
		exit 1
	fi
done

#check driver file
drivdirs=("sangfor.app.proxy.hook.kext" "tun.kext")
for drivdir in ${drivdirs[*]}
do
	if [ ! -d $ECHOME/${subdirs[3]}/$drivdir ]
	then
		exit 1
	fi
done
drivshs=("StartL3VPN.sh" "StartTcp.sh" "StopL3VPN.sh" "StopTcp.sh" "do.sh")
for drivsh in ${drivshs[*]}
do
	if [ ! -f $ECHOME/${subdirs[3]}/$drivsh ]
	then
		exit 1
	fi
done

exit 0

