#!/bin/bash

cd `dirname $0`
ECHOME=$(dirname $(pwd))
BINPATH=${ECHOME}/bin
APPSPATH=${ECHOME}/apps

#cd $TMPPATH
echo $ECHOME
echo $BINPATH
echo $APPSPATH

#parse input params
if [ x$1 == x ]
then
	exit 1
fi

#parse input param
key_name=""
dir_name=""
file_name=""
temp_name=""
session=""
rc_name=""

for arg in "$@"
do
	if [ "$arg" = "-d" ]
	then   
		key_name="$arg"
	elif [ "$arg" = "-n" ]
	then
		key_name="$arg"
	elif [ "$arg" = "-t" ]
	then
		key_name="$arg"
	elif [ "$arg" = "-s" ]
	then
		key_name="$arg"
    elif [ "$arg" = "-r" ]
    then
        key_name="$arg"
	else
			if [ "$key_name" = "-d" ]
			then   
				dir_name="$arg"
			elif [ "$key_name" = "-n" ]
			then
				file_name="$arg"
			elif [ "$key_name" = "-t" ]
			then
				temp_name="$arg"
			elif [ "$key_name" = "-s" ]
			then
				session="$arg"
            elif [ "$key_name" = "-r" ]
            then
                rc_name="$arg"
			else
				echo "unknow args:${arg} key:${key_name}."
				exit 1
			fi
	fi
done

#check dir
echo "check dir."

if [ "$dir_name" = "" ] || [ "$file_name" = "" ] || [ "$temp_name" = "" ] || [ "$session" = "" ]
then
	echo "invalid param."
	exit 1;
fi

subdirs=("bin" "apps")
for subdir in ${subdirs[*]}
do
	if [ ! -d $ECHOME/$subdir ]
	then
		mkdir -p $ECHOME/$subdir
	fi
done

if [ ! -d $ECHOME/apps/$dir_name ] 
then
	mkdir -p $ECHOME/apps/$dir_name
fi

#copy file
echo "copy file."
app_path="$ECHOME/apps/$dir_name/$file_name.app"
rc_path="${app_path}/Contents/Resources"
if [ ! -d $app_path ]
then
	cp -r $ECHOME/bin/$temp_name $app_path
	if [ $? -ne 0 ]
	then
		echo "cp file failed."
		exit 1
	fi
fi

content_path=$app_path/Contents
plist_path=$app_path/Contents/Info.plist
plist_bk_path=$ECHOME/Info.plist

#cp info.plist to app
cp $plist_bk_path $plist_path
chmod a+wr $plist_path
sed -i "" "s/custom_bundle_name/$file_name/g" $plist_path
sed -i "" "s/com.sangfor.RSessionClient.sid/com.sangfor.RSessionClient.$dir_name/g" $plist_path
sed -i "" "s/icon.icns/$rc_name/g" $plist_path
if [ $? -ne 0 ]
then
    echo "update plist failed."
    exit 1
fi

#open app
echo ${app_path} ${session}
open -a ${app_path} --args -s ${session}
if [ $? -ne 0 ]
then
	echo "open app failed."
	exit 1
fi

echo "done success."

exit 0

