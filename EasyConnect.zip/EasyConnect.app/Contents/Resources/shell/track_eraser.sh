#!/bin/bash

echo "Start erase tracks."

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:$PATH
export PATH

#erase firefox tracks
function erase_track_firefox()
{
echo "Erase firefox tracks."
if [ "$1" = "linux" ]
then
	#erase cache
	rm -rf $HOME/.mozilla/firefox/*.default/Cache/
	#erase history
	rm -rf $HOME/.mozilla/firefox/*.default/places.*
	rm -rf $HOME/.mozilla/firefox/*.default/formhistory.sqlite
	#erase cookies
	rm -rf $HOME/.mozilla/firefox/*.default/cookies.sqlite
	#erase download
	rm -rf $HOME/.mozilla/firefox/*.default/downloads.sqlite
elif [ "$1" = "mac" ]
then
	#erase cache
	rm -rf $HOME/Library/Caches/Firefox/Profiles/*.default/*
	#erase cookies
	rm -rf $HOME/Library/Cookies/Cookies.plist
	#erase history
	rm -rf $HOME/Library/Application\ Support/Firefox/Profiles/*.default/*sqlite*
fi
}

#erase opera tracks
function erase_track_opera()
{
echo "Erase opera tracks."
if [ "$1" = "linux" ]
then
	#erase cache
	rm -rf $HOME/.opera/cache/*
	rm -rf $HOME/.opera/opcache/*
	#erase history
	rm -rf $HOME/.opera/global_history.dat
	rm -rf $HOME/.opera/typed_history.xml
	rm -rf $HOME/.opera/vlink4.dat
	#erase cookies
	rm -rf $HOME/.opera/cookies4.dat
	rm -rf $HOME/.opera/sessions/*
fi
}

#erase safari tracks
function erase_track_safari()
{
echo "Erase safari tracks."
if [ "$1" = "mac" ]
then
	#erase cache
	rm -rf $HOME/Library/Caches/com.apple.Safari/*
	#erase history
	rm -rf $HOME/Library/Safari/*
	#erase cookies
	rm -rf $HOME/Library/Cookies/Cookies.plist
fi
}

#erase track for linux
function erase_track_linux()
{
	echo "Erase track for linux."
	erase_track_firefox "linux"
	erase_track_opera "linux"
}

#erase track for mac
function erase_track_mac()
{
	echo "Erase track for mac."
	erase_track_firefox "mac"
	erase_track_safari "mac"
}

# $2 browser type
if [ "$2" = "1" ]
then
	browser="firefox"
elif [ "$2" = "3" ]
then
	browser="opera"
elif [ "$2" = "4" ]
then
	browser="safari"
else
	browser="unknown"
fi

echo $1 $browser

#clean cache while the browser process not exist
ps aux | grep -i $browser | grep -v grep
if [ $? -ne 0 ]
then
	if [ $browser = "firefox" ]
	then 
		erase_track_firefox $1
	elif [ $browser = "opera" ]
	then
		erase_track_opera $1
	elif [ $browser = "safari" ]
	then
		erase_track_safari $1
	else
		echo "Unsupported browser."
	fi
fi

echo "Erase tracks complete.."
