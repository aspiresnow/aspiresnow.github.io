#!/bin/sh
unlink /Applications/EasyConnect.app/Contents/Resources/logs/check_proxy_state.log
exec &> /Applications/EasyConnect.app/Contents/Resources/logs/check_proxy_state.log 2>&1

username=`stat -f %Su /dev/console`
contextpid=$(ps -axj  | grep loginwindow | awk "/^$username / {print \$2;exit}")

launchstate=`sudo launchctl bsexec $contextpid sudo -u $username launchctl list | grep com.sangfor.ECAgentProxy`
if [[ -z $launchstate ]]; then
    date '+%Y-%m-%d %H:%M:%S'
    echo "check failed, force start ecagent proxy for current user"
    sudo launchctl bsexec $contextpid sudo -u $username launchctl load /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
else
    exit 0
fi

launchstate=`sudo launchctl bsexec $contextpid sudo -u $username launchctl list | grep com.sangfor.ECAgentProxy`
if [[ -z $launchstate ]]; then
    echo "check failed, start ECAgentProxy failed, need user re login"
else
    echo "start ecagent"
    exit 0
fi



