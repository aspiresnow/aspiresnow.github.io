#!/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:$PATH
export PATH

#change $1 to browser name
browser=""
if [ "$1" = "1" ]
then   
	browser="firefox"
elif [ "$1" = "2" ]
then
	browser="chrome"
elif [ "$1" = "3" ]
then 
	browser="opera"
elif [ "$1" = "4" ]
then
	browser="safari"
else
	exit 1;
fi

echo $browser > /tmp/browsershell.txt

#search browser through process list
#java client fetch all browsers, analyze the path and save it.
ps aux | awk {print'$11'} | grep -i $browser | grep -v grep |
while read line
do
    
    echo $line | grep -iE "$browser$" > /dev/null
    if [ $? -eq 0 ] && [ -f $line ]
    then
        echo $line >> /tmp/browsershell.txt
        echo $line
    fi
done

exit 0;
