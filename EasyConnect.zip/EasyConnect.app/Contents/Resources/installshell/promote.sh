#!/bin/bash

#promote operation

cd `dirname $0`
ECHOME=$(dirname $(pwd))

#detect version
#different os version use different driver

MACOSX_SNOWLEAPORD_VERSION=10.6.0
MACOSX_MOUNTAINLION_VERSION=10.8.0
MACOSX_MAVERICKS_VERSION=10.9.0

VERSION_NAME="LION"

function detect_version()
{
	local v_cur=`echo $1 | awk -F'.' '{printf "%03d%03d%03d", $1,$2,$3}'`
	local v_10_6=`echo $MACOSX_SNOWLEAPORD_VERSION | awk -F'.' '{printf "%03d%03d%03d", $1,$2,$3}'`
	local v_10_8=`echo $MACOSX_MOUNTAINLION_VERSION | awk -F'.' '{printf "%03d%03d%03d", $1,$2,$3}'`
	local v_10_9=`echo $MACOSX_MAVERICKS_VERSION | awk -F'.' '{printf "%03d%03d%03d", $1,$2,$3}'`

	if [ "$v_cur" \< "$v_10_8" ]
	then
		VERSION_NAME="LION"
	elif [ "$v_cur" \< "$v_10_9" ]
	then
		VERSION_NAME="MOUNTAINLIONLION"
	else
		VERSION_NAME="MAVERICKS"
	fi
}

#no uninstall while the driver already in use, to avoid kernel crash
tunmod="sangfor.ssl.tun"
proxymod="sangfor.app.proxy.hook"

if [ -d $ECHOME/kext/tun.kext ]
then
	rm -rf $ECHOME/kext/tun.kext
fi

if [ -d $ECHOME/kext/sangfor.app.proxy.hook.kext ]
then
	rm -rf $ECHOME/kext/sangfor.app.proxy.hook.kext
fi

MACOSX_CURVERSION=`sw_vers -productVersion`
detect_version $MACOSX_CURVERSION

mv $ECHOME/kext/tun.kext.10.6 $ECHOME/kext/tun.kext

if [ $VERSION_NAME == "LION" ]
then
	#Snow Leapord, Lion
	mv $ECHOME/kext/sangfor.app.proxy.hook.kext.10.6 $ECHOME/kext/sangfor.app.proxy.hook.kext
	if [ -f $ECHOME/bin/svpnservice_new.10.6 ]
	then
		mv $ECHOME/bin/svpnservice_new.10.6 $ECHOME/bin/svpnservice
	fi
elif [ $VERSION_NAME == "MOUNTAINLIONLION" ]
then
	#Mountain Lion
	mv $ECHOME/kext/sangfor.app.proxy.hook.kext.10.8 $ECHOME/kext/sangfor.app.proxy.hook.kext
	if [ -f $ECHOME/bin/svpnservice_new.10.8 ]
	then
		mv $ECHOME/bin/svpnservice_new.10.8 $ECHOME/bin/svpnservice
	fi
else
	#MAVERICKS
	mv $ECHOME/kext/sangfor.app.proxy.hook.kext.10.9 $ECHOME/kext/sangfor.app.proxy.hook.kext
	if [ -f $ECHOME/bin/svpnservice_new.10.8 ]
	then
		mv $ECHOME/bin/svpnservice_new.10.8 $ECHOME/bin/svpnservice
	fi
fi

function promote_file()
{
	chown root:wheel $1
	if [ $? -ne 0 ]
	then 
		echo "chown root:wheel $1 failed:$?."
		exit 1
	fi

	chmod 6711 $1
	if [ $? -ne 0 ]
	then
	    echo "chmod 6711 $1 failed:$?."
	    exit 1
	fi
}

files=("svpnservice" "ECAgent" "EasyMonitor")
for file in ${files[*]}
do
	if [ ! -e $ECHOME/bin/$file ]
	then
		echo "$ECHOME/bin/$file is not exist!"
		exit 1
	fi
	promote_file $ECHOME/bin/$file
done

# chown root:wheel $ECHOME/bin/svpnservice
# if [ $? -ne 0 ]
# then
#     echo "chown root:wheel svpnservice failed:$?."
# 	exit 1
# fi

# chmod 6711 $ECHOME/bin/svpnservice
# if [ $? -ne 0 ]
# then
#     echo "chmod 6711 svpnservice failed:$?."
#     exit 1
# fi

#delete /tmp/promote
tmpromote=/tmp/promote
if [ -f $tmpromote ]
then
	rm -f $tmpromote
fi

#change access mode, everyone can visit it
JAVALOCK=/tmp/SangforSSLJava.lock
if [ -f $JAVALOCK ]
then
	chmod 0777 $JAVALOCK
fi
SVPNSERVICELOCK=/tmp/SangforSSL.lock
if [ -f $SVPNSERVICELOCK ]
then
	chmod 0777 $SVPNSERVICELOCK
fi

exit 0

