#!/bin/bash

#@return 0 succeed
#        none 0 fail : 1 decompress failed  2 java unavailable

LIBPATH=/usr/local/lib

#TMPPATH=$(dirname $(pwd))
#echo $TMPPATH
cd `dirname $0`
ECHOME=$(dirname $(pwd))
#cd $TMPPATH
echo $ECHOME

SHELLPWD=$ECHOME/installshell #script dir
OLDECHOME=$HOME/.sangfor

echo "Mac OS X package start installation..."
echo `pwd`


#sangfor.app.proxy.hook 卸载时需要所有attach的连接都断开时才能卸载
#方法是：
#首先检查是否需要更新内核扩展
#如果尝试1分钟后卸载仍不成功，则还是直接卸载
#(如果更新内核扩展，此处还是可能出现崩溃，这里最好的解决方案是可以重启)
function unloadtcpkext()
{
	modulename="sangfor.app.proxy.hook"
	kextstat  | grep $modulename
	if [ $? -ne 0 ]; then
		echo "do not find tcp kext load"
		return
	fi

	older_tcp_kext_md5=`cat /tmp/back.sangfor.older_tcp_kext_md5`
	newer_tcp_kext_md5=`md5 /Applications/EasyConnect.app/Contents/Resources/kext/sangfor.app.proxy.hook.kext/Contents/MacOS/sangfor.app.proxy.hook | awk '{print $4}'`
	rm -rf /tmp/back.sangfor.older_tcp_kext_md5
	echo "older_tcp_kext_md5 : "$older_tcp_kext_md5
	echo "newer_tcp_kext_md5 : "$newer_tcp_kext_md5
	if [ "$older_tcp_kext_md5" = "$newer_tcp_kext_md5" ]; then
		echo "md5 is equle, do not unload tcp kext!"
		return
	fi

	# 0 success 1 failed
	unloadok=1 
	unloadtimes=0
	while [ 1 ]
	do
		unloadtimes=`expr $unloadtimes + 1`
		kextunload -v 6 -b $modulename
		unloadok=$?
		dmesg > /tmp/EasyConnect.unloadtcpkextdmesg.log 2>&1
		if [ $unloadok -eq 0 ]; then
        	break
    	fi

		#内核扩展里最多支持了40次，这里写60次是为了避免内核扩展出错，会导致这里一直循环
    	if [ $unloadtimes -ge 60 ]; then
			echo "unload kext failed, try max times"
        	break
    	else
			echo "unload kext failed, try again, code= "$unloadok" try times: "$unloadtimes 
			sleep 1
		fi
	done
	
	if [ $unloadok -eq 0 ]; then
		echo "unload kext suucess, try times:"$unloadtimes
	else
		echo "unload kext failed, try times:"$unloadtimes
		touch /tmp/tmp.sangfor.notifirestartmac
	fi

}

#sangfor.ssl.tun 直接卸载
function unloadtunkext()
{
	modulename="sangfor.ssl.tun"
	kextstat  | grep $modulename
	if [ $? -ne 0 ]; then
		echo "do not find tun kext load"
		return
	fi

	older_tun_kext_md5=`cat /tmp/back.sangfor.older_tcp_tun_md5`
	newer_tun_kext_md5=`sudo md5 /Applications/EasyConnect.app/Contents/Resources/kext/tun.kext/Contents/MacOS/tun | awk '{print $4}'`
	rm -rf /tmp/back.sangfor.older_tcp_tun_md5
	echo "older_tun_kext_md5 : "$older_tun_kext_md5
	echo "newer_tun_kext_md5 : "$newer_tun_kext_md5
	if [ "$older_tun_kext_md5" = "$newer_tun_kext_md5" ]; then
		echo "md5 is equle, do not unload tun kext!"
		return
	fi

	kextunload -v 6 -b $modulename
	dmesg > /tmp/EasyConnect.unloadtunkextdmesg.log 2>&1
}

#0 succeed, other fail
function uninstallkext()
{
	unloadtunkext
	unloadtcpkext
}

function installkext()
{
	/Applications/EasyConnect.app/Contents/Resources/kext/StartL3VPN.sh /Applications/EasyConnect.app/Contents/Resources/
	/Applications/EasyConnect.app/Contents/Resources/kext/StartTcp.sh /Applications/EasyConnect.app/Contents/Resources/
}



#0 succeed, 1 fail
function checkinstall()
{
	files=("svpnservice" "svpnservice_new" "ECAgent" "EasyMonitor" "ECAgentProxy")
	for file in ${files[*]}
	do

		if [ ! -f $ECHOME/bin/$file ]
		then
			echo "$ECHOME/bin/$file not exist!"
			return 1
		fi

		if [ -u $ECHOME/bin/$file ] && [ -g $ECHOME/bin/$file ]
		then
			echo "install all ok!"
			return 0
		else
			echo "password not right!"
			return 1
		fi
	done 
	# localbin=$ECHOME/bin/svpnservice
	# localbinnew=$ECHOME/bin/svpnservice_new
	# if [ ! -f $localbin ]
	# then
	# 	if [ ! -f $localbinnew ] #check file exist or not
	# 	then
	# 		echo "$localbin and $localbinnew not exist!"
	# 		exit 1
	# 	fi
	# 	return 1
	# fi

	# if [ -u $localbin ] && [ -g $localbin ]
	# then
	# 	echo "install all ok!"
	# 	return 0
	# else
	# 	echo "password not right!"
	# 	return 1
	# fi
}

function do_update()
{
	$ECHOME/bin/svpnservice -h $ECHOME -x "$SHELLPWD/promote.sh"
}

function do_install()
{
	chmod +x $SHELLPWD/promote

	#promote
	if [ "$UID" -eq "0" ]
	then
		$SHELLPWD/promote.sh $ECHOME
	else
		tmpromote=/tmp/promote
		if [ -f $tmpromote ] && [ -u $tmpromote ] && [ -g $tmpromote ]
		then
			$tmpromote "$SHELLPWD/promote.sh"
		else
			$SHELLPWD/promote "$SHELLPWD/promote.sh"
		fi
	fi

	sleep 2
}

function do_installlibs()
{
    # pluginbin=$ECHOME/bin/EasyConnectPlugin.plugin
    # oldplugin="/Library/Internet Plug-Ins/EasyConnectPlugin.plugin"
    # if [ -d "$oldplugin" ]
    # then
    #     rm -rf -d "$oldplugin"
    # fi

    # ln -fs $pluginbin "/Library/Internet Plug-Ins/"

    if [ ! -d "$LIBPATH" ]
    then
        mkdir -p "$LIBPATH"
    fi

	subdirs=("libcrypto.1.0.0.dylib" "libngs.dylib" "libnvcclip.dylib" "libnvcsnd.dylib" "libssl.1.0.0.dylib" 
	"libnspr4.dylib" "libplc4.dylib" "libplds4.dylib" "libsoftokn3.dylib" "libssl3.dylib" "libsmime3.dylib" 
	"libnssutil3.dylib" "libnssdbm3.dylib" "libnssckbi.dylib" "libnss3.dylib" "libfreebl3.dylib")
	for libname in ${subdirs[*]}
	do
		if [ -f $LIBPATH/$libname ]
		then
			rm -f $LIBPATH/$libname
        fi
	done

	ln -fs $ECHOME/Libs/*.dylib $LIBPATH/
}

function do_install_launch_daemon
{
	echo "install launch daemon"

	items=("com.sangfor.EasyMonitor.plist")
	for item in ${items[*]}
	do
		echo "install launch daemon $item"

		if [ -e $ECHOME/LaunchDaemons/$item ]
		then
			cp $ECHOME/LaunchDaemons/$item /Library/LaunchDaemons/
			chown root:wheel /Library/LaunchDaemons/$item
		else
		    echo "install launch daemon $item failed"
			exit 1
		fi
	done
}

function do_install_launch_agent
{
	echo "install launch agent"

	items=("com.sangfor.ECAgentProxy.plist")
	for item in ${items[*]}
	do
		echo "install launch agents $item"

		if [ -e $ECHOME/LaunchAgents/$item ]
		then
			cp $ECHOME/LaunchAgents/$item /Library/LaunchAgents/
			chown root:wheel /Library/LaunchAgents/$item
		else
		    echo "install launch agents $item failed"
			exit 1
		fi
	done
}



#start installation

export LANG=zh_CN.UTF-8

echo "env lang = "$LANG

#change execute authority
chmod -R u+rwx,g+rwx,o+rx /Applications/EasyConnect.app/Contents
chown -R root:admin /Applications/EasyConnect.app/Contents

chmod +x $SHELLPWD/*.sh
chmod +x $ECHOME/shell/*.sh
chmod a+wr $ECHOME/conf
chmod a+wr $ECHOME/apps

chmod -R u+rwx,g+rwx,o+rwx $ECHOME/wheelfile
chown -R root:wheel $ECHOME/wheelfile

chmod u+x,g+x,o+x $ECHOME/kext/*.sh

if [ -f $ECHOME/bin/svpnservice ] && [ -u $ECHOME/bin/svpnservice ] && [ -g $ECHOME/bin/svpnservice ]
then
	do_update
else
	do_install
fi

do_installlibs

do_install_launch_daemon
do_install_launch_agent

# 推出 EasyConnect 避免影响下一次安装
echo "detach EasyConnect"
IFS=$'\n';for name in `ls -d /Volumes/* | grep EasyConnect`
do
    hdiutil detach $name -force
    echo "detach $name"
done

##delete .sangfor
if [ -d $OLDECHOME ]
then
    rm -rf $OLDECHOME
fi

function do_install_launch_agent
{
	launchctl load /Library/LaunchDaemons/com.sangfor.EasyMonitor.plist
	launchctl stop com.sangfor.EasyMonitor
	launchctl start com.sangfor.EasyMonitor

	killall ECAgentProxy
	proxypids=$(ps aux | grep -v grep | grep ECAgentProxy | awk '{print $2}')
	for proxypid in $proxypidsr
	do
    	kill -9 $proxypid
	done

	#当前用户
	username=`stat -f %Su /dev/console`
	#所有的用户
	loginusers=`ps aux | grep -v grep | grep loginwindow | awk '{print $1}'`
	for loginuser in $loginusers
	do
		echo "deal ECAgentProxy of "$loginuser

		#搜索该用户上下文相关的进程id
		contextpid=$(ps -axj  | grep loginwindow | awk "/^$loginuser / {print \$2;exit}")
		echo $contextpid
		if [[ -z "$contextpid" ]]; then
			echo "can not find contextpid for user "$loginuser
		else
			sudo launchctl bsexec $contextpid sudo -u $loginuser launchctl unload /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
			sudo launchctl bsexec $contextpid sudo -u $loginuser launchctl load /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
			sudo launchctl bsexec $contextpid sudo -u $loginuser launchctl stop /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
			sudo launchctl bsexec $contextpid sudo -u $loginuser launchctl start /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
		fi

		launchstate=`sudo launchctl bsexec $contextpid sudo -u $loginuser launchctl list | grep com.sangfor.ECAgentProxy`

		if [[ -z $launchstate ]]; then
			echo "start ecagent proxy failed for user "$loginuser
            #需要保证在当前用户下启动成功
			if [ $loginuser = $username ]; then
				echo "force start ecagent proxy for current user"
				sudo -u $username launchctl unload /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
				sudo -u $username launchctl load /Library/LaunchAgents/com.sangfor.ECAgentProxy.plist
				sudo -u $username launchctl stop com.sangfor.ECAgentProxy.plist
				sudo -u $username launchctl start com.sangfor.ECAgentProxy.plist
			fi
		else
			echo "start ecagent proxy succ for user "$loginuser
		fi
		
	done
}

uninstallkext
checkinstall

if [ $? -eq 0 ]
then
	do_install_launch_agent
	installkext
	echo "Mac OS X EasyConnect installed success."
else
    if [ -d /Applications/EasyConnect.app ]
    then
        rm -rf /Applications/EasyConnect.app
    fi
	echo "Mac OS X EasyConnect installed failed."
    exit 1
fi

